<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('membros', function (Blueprint $table) {
            $table->id('idt_membro');
            $table->foreignId('idt_associacao')->nullable()->constrained('associacoes', 'idt_associacao')->cascadeOnDelete();
            $table->string('num_cpf_membro', 14)->unique();
            $table->string('nom_membro');
            $table->string('eml_membro')->unique();
            $table->string('tel_membro', 20)->nullable();
            $table->date('dat_nascimento')->nullable();
            $table->string('num_cep', 10)->nullable();               // CEP
            $table->string('end_logradouro', 150)->nullable();       // Bairro/Complemento
            $table->string('end_numero', 20)->nullable();            // Número/Apartamento
            $table->string('end_complemento', 150)->nullable();      // Rua/Avenida
            $table->string('nom_apelido', 100)->nullable();          // Apelido
            $table->string('tip_associado', 50)->default('membro'); // Tipo de associação
            $table->string('usu_autorizador')->nullable();
            $table->boolean('ind_aprovado')->default(false);
            $table->string('des_telegram_chat_id', 50)->nullable();
            $table->boolean('ind_notificar_whatsapp')->default(true);
            $table->boolean('ind_notificar_email')->default(true);
            $table->boolean('ind_notificar_telegram')->default(false);

            $table->timestamps();

            $table->index('tip_associado');
            $table->index('nom_membro');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('membros');
    }
};
