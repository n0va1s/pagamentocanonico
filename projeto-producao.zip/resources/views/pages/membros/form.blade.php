<?php

use App\Enums\Perfil;
use App\Models\Membro;
use Illuminate\Validation\Rule;
use Livewire\Volt\Component;

new class extends Component {

    public ?Membro $membro = null;

    // Dados pessoais
    public ?int $idt_associacao          = null;
    public string $nom_membro            = '';
    public string $nom_ofx               = '';
    public string $nom_apelido           = '';
    public string $eml_membro            = '';
    public string $tel_membro            = '';

    // Endereço
    public string $end_logradouro        = '';
    public string $end_numero            = '';
    public string $end_complemento       = '';

    // Associação
    public string $tip_associado         = '';



    public function mount(?Membro $membro = null): void
    {
        $this->membro = $membro;

        if ($membro?->exists) {
            $this->idt_associacao        = $membro->idt_associacao;
            $this->nom_membro            = $membro->nom_membro;
            $this->nom_ofx               = $membro->nom_ofx ?? '';
            $this->nom_apelido           = $membro->nom_apelido ?? '';
            $this->eml_membro            = $membro->eml_membro;
            $this->tel_membro            = $membro->tel_membro ?? '';
            $this->end_logradouro        = $membro->end_logradouro ?? '';
            $this->end_numero            = $membro->end_numero ?? '';
            $this->end_complemento       = $membro->end_complemento ?? '';
            $this->tip_associado         = $membro->tip_associado->value ?? '';

        } else {
            $this->idt_associacao        = auth()->user()->membro?->idt_associacao;
            $this->tip_associado         = Perfil::MEMBRO->value;
        }
    }

    protected function regras(): array
    {
        $ignorarId = $this->membro?->idt_membro;

        return [
            'idt_associacao'         => ['required', 'exists:associacoes,idt_associacao'],
            'nom_membro'             => ['required', 'string', 'max:255'],
            'nom_ofx'                => ['nullable', 'string', 'max:255'],
            'nom_apelido'            => ['nullable', 'string', 'max:100'],
            'eml_membro'             => ['required', 'email', 'max:255', Rule::unique('membros', 'eml_membro')->ignore($ignorarId, 'idt_membro')],
            'tel_membro'             => ['nullable', 'string', 'max:20'],
            'end_logradouro'         => ['nullable', 'string', 'max:150'],
            'end_numero'             => ['nullable', 'string', 'max:20'],
            'end_complemento'        => ['nullable', 'string', 'max:150'],
            'tip_associado'          => ['required', Rule::enum(Perfil::class)],

        ];
    }

    protected function mensagens(): array
    {
        return [
            'idt_associacao.required' => 'A associação é obrigatória.',
            'idt_associacao.exists'   => 'A associação selecionada é inválida.',
            'nom_membro.required'    => 'O nome do membro é obrigatório.',
            'eml_membro.required'    => 'O e-mail é obrigatório.',
            'eml_membro.email'       => 'Informe um e-mail válido.',
            'eml_membro.unique'      => 'Este e-mail já está cadastrado.',
            'tip_associado.required' => 'O tipo de associação é obrigatório.',
            'tip_associado.enum'     => 'O tipo de associação selecionado é inválido.',
        ];
    }

    public function salvar(): void
    {
        if (!auth()->user()->isAdmin()) {
            $this->idt_associacao = auth()->user()->membro?->idt_associacao;
        }

        $dados = $this->validate($this->regras(), $this->mensagens());

        if ($this->membro?->exists) {
            $this->membro->update($dados);
            \Flux::toast(variant: 'success', text: __('messages.alerts.success.saved'));
        } else {
            $dados['ind_aprovado'] = true; // Auto approve manually created members
            Membro::create($dados);
            \Flux::toast(variant: 'success', text: __('messages.alerts.success.saved'));
            $this->redirecionar();
        }
    }

    public function redirecionar(): void
    {
        $this->redirectRoute('membros.index', navigate: true);
    }

    public function with(): array
    {
        return [
            'tiposAssociado' => Perfil::cases(),
            'associacoes'    => \App\Models\Associacao::orderBy('nom_associacao')->get(),
            'editando'       => $this->membro?->exists ?? false,
        ];
    }
}; ?>

<div>
    <form wire:submit="salvar" class="space-y-6">

        {{-- Dados Pessoais --}}
        <flux:card class="space-y-6">
            <div>
                <flux:heading size="sm">Dados Pessoais</flux:heading>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

                <flux:field class="md:col-span-2">
                    <flux:label required for="nom_membro">Nome completo</flux:label>
                    <flux:input
                        id="nom_membro"
                        wire:model="nom_membro"
                        placeholder="Ex: João Paulo Silva"
                        autocomplete="off"
                    />
                    <flux:error name="nom_membro" />
                </flux:field>

                <flux:field class="md:col-span-2">
                    <flux:label for="nom_apelido">Apelido</flux:label>
                    <flux:input
                        id="nom_apelido"
                        wire:model="nom_apelido"
                        placeholder="Ex: Joãozinho"
                        autocomplete="off"
                    />
                    <flux:error name="nom_apelido" />
                </flux:field>

                <flux:field class="md:col-span-2">
                    <flux:label for="nom_ofx">Nome no extrato bancário</flux:label>
                    <flux:input
                        id="nom_ofx"
                        wire:model="nom_ofx"
                        placeholder="Ex: JOAO PAULO SILVA"
                        autocomplete="off"
                    />
                    <flux:description>
                        Preencha somente se o nome no extrato OFX for diferente do nome cadastrado acima.
                        Usado para identificar pagamentos automaticamente.
                    </flux:description>
                    <flux:error name="nom_ofx" />
                </flux:field>

                <flux:field>
                    <flux:label required for="eml_membro">E-mail</flux:label>
                    <flux:input
                        id="eml_membro"
                        type="email"
                        wire:model="eml_membro"
                        placeholder="joao@email.com"
                        autocomplete="off"
                    />
                    <flux:error name="eml_membro" />
                </flux:field>

                <flux:field>
                    <flux:label for="tel_membro">Telefone</flux:label>
                    <flux:input
                        id="tel_membro"
                        wire:model="tel_membro"
                        placeholder="(11) 99999-9999"
                    />
                    <flux:error name="tel_membro" />
                </flux:field>

                @if(auth()->user()->isAdmin())
                <flux:field>
                    <flux:label required for="idt_associacao">Associação</flux:label>
                    <flux:select id="idt_associacao" wire:model="idt_associacao">
                        <flux:select.option value="">Selecione...</flux:select.option>
                        @foreach ($associacoes as $assoc)
                            <flux:select.option value="{{ $assoc->idt_associacao }}">
                                {{ $assoc->nom_associacao }}
                            </flux:select.option>
                        @endforeach
                    </flux:select>
                    <flux:error name="idt_associacao" />
                </flux:field>
                @endif

                @if($editando)
                <flux:field>
                    <flux:label required for="tip_associado">Tipo de associação</flux:label>
                    <flux:select id="tip_associado" wire:model="tip_associado">
                        <flux:select.option value="">Selecione...</flux:select.option>
                        @foreach ($tiposAssociado as $tipo)
                            <flux:select.option value="{{ $tipo->value }}">
                                {{ $tipo->label() }}
                            </flux:select.option>
                        @endforeach
                    </flux:select>
                    <flux:error name="tip_associado" />
                </flux:field>
                @endif

            </div>
        </flux:card>

        {{-- Endereço --}}
        <flux:card class="space-y-6">
            <div>
                <flux:heading size="sm">Endereço</flux:heading>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

                <flux:field class="md:col-span-2">
                    <flux:label for="end_logradouro">Logradouro</flux:label>
                    <flux:input
                        id="end_logradouro"
                        wire:model="end_logradouro"
                        placeholder="Rua das Flores"
                    />
                    <flux:error name="end_logradouro" />
                </flux:field>

                <flux:field>
                    <flux:label for="end_numero">Número</flux:label>
                    <flux:input
                        id="end_numero"
                        wire:model="end_numero"
                        placeholder="123"
                    />
                    <flux:error name="end_numero" />
                </flux:field>

                <flux:field class="md:col-span-3">
                    <flux:label for="end_complemento">Complemento / Bairro</flux:label>
                    <flux:input
                        id="end_complemento"
                        wire:model="end_complemento"
                        placeholder="Apto 42 - Jardim Primavera"
                    />
                    <flux:error name="end_complemento" />
                </flux:field>

            </div>
        </flux:card>



        {{-- Ações --}}
        <div class="flex items-center justify-end gap-3">
            <flux:button
                type="button"
                variant="ghost"
                wire:click="redirecionar"
            >
                Cancelar
            </flux:button>

            <flux:button type="submit" variant="primary" wire:loading.attr="disabled">
                <span wire:loading.remove>
                    {{ $editando ? 'Salvar alterações' : 'Cadastrar membro' }}
                </span>
                <span wire:loading>Salvando...</span>
            </flux:button>
        </div>

    </form>
</div>
