<?php

use App\Models\Membro;
use App\Models\Ofx;
use App\Models\Resumo;
use App\Models\Transacao;

use Livewire\Volt\Component;
use Livewire\Attributes\Title;

new #[Title('Dashboard')] class extends Component {
    public ?int $selectedImportId = null;
    public $selectedAssociacaoId = null;
    public ?int $selectedYear = null;

    // Member properties
    public string $activeTab = 'pagamentos';
    public string $nom_membro = '';
    public ?string $nom_apelido = null;
    public ?string $tel_membro = null;
    public ?string $end_logradouro = null;
    public ?string $end_numero = null;
    public ?string $end_complemento = null;
    public ?string $des_telegram_chat_id = null;

    public string $contactName = '';
    public string $contactEmail = '';
    public string $contactMessage = '';
    public ?int $contactAssociacaoId = null;

    public function mount(): void
    {
        $user = auth()->user();
        if ($user->isMembro()) {
            $membro = $user->membro;
            if ($membro) {
                $this->nom_membro = $membro->nom_membro;
                $this->nom_apelido = $membro->nom_apelido;
                $this->tel_membro = $membro->tel_membro;
                $this->end_logradouro = $membro->end_logradouro;
                $this->end_numero = $membro->end_numero;
                $this->end_complemento = $membro->end_complemento;
                $this->des_telegram_chat_id = $membro->des_telegram_chat_id;

                $this->contactName = $membro->nom_membro;
                $this->contactEmail = $membro->eml_membro;
                $this->contactAssociacaoId = $membro->idt_associacao;
            } else {
                $this->contactName = $user->name;
                $this->contactEmail = $user->email;
                $this->contactAssociacaoId = $user->membro?->idt_associacao;
            }
        } else {
            $importId = request()->query('import') ?? request()->query('ofx');
            if ($importId) {
                $this->selectedImportId = (int) $importId;
            } else {
                $latest = Ofx::withoutGlobalScope('associacao')->latest()->first();
                $this->selectedImportId = $latest ? $latest->idt_ofx : null;
            }
            
            if (!$user->isAdmin()) {
                $this->selectedAssociacaoId = $user->membro?->idt_associacao;
            }
        }
    }

    public function updatedSelectedImportId(): void
    {
        $this->redirect(route('dashboard', ['import' => $this->selectedImportId]), navigate: true);
    }



    public function updateProfile(): void
    {
        $membro = auth()->user()->membro;
        if (!$membro) {
            \Flux::toast(variant: 'danger', text: 'Membro não cadastrado.');
            return;
        }
        $this->validate([
            'nom_membro' => 'required|string|max:255',
            'nom_apelido' => 'nullable|string|max:100',
            'tel_membro' => 'nullable|string|max:20',
            'end_logradouro' => 'nullable|string|max:150',
            'end_numero' => 'nullable|string|max:20',
            'end_complemento' => 'nullable|string|max:150',
            'des_telegram_chat_id' => 'nullable|string|max:50',
        ]);
        $membro->update([
            'nom_membro' => $this->nom_membro,
            'nom_apelido' => $this->nom_apelido ?: null,
            'tel_membro' => $this->tel_membro,
            'end_logradouro' => $this->end_logradouro,
            'end_numero' => $this->end_numero,
            'end_complemento' => $this->end_complemento,
            'des_telegram_chat_id' => $this->des_telegram_chat_id,
        ]);
        \Flux::toast(variant: 'success', text: __('messages.alerts.success.saved'));
    }

    public function submitContact(): void
    {
        $membro = auth()->user()->membro;
        $this->contactAssociacaoId = auth()->user()->membro?->idt_associacao;
        $rules = [
            'contactName' => 'required|string|max:100',
            'contactEmail' => 'required|email|max:100',
            'contactMessage' => 'required|string|max:1000',
        ];
        if (!$membro) {
            $rules['contactAssociacaoId'] = 'nullable';
        }
        $this->validate($rules);

        \App\Models\Contato::create([
            'nome' => $this->contactName,
            'email' => $this->contactEmail,
            'mensagem' => $this->contactMessage,
            'idt_associacao' => $membro ? $membro->idt_associacao : $this->contactAssociacaoId,
        ]);

        $botToken = config('services.telegram.bot_token', '');
        $chatId = config('services.telegram.contact_chat_id') ?: env('TELEGRAM_CONTACT_CHAT_ID', '');
        $enviouTelegram = false;
        if (filled($botToken) && filled($chatId)) {
            $texto = "📩 <b>Nova Mensagem de Contato</b>\n" .
                     "👤 <b>Nome:</b> {$this->contactName}\n" .
                     "✉️ <b>E-mail:</b> {$this->contactEmail}\n" .
                     "💬 <b>Mensagem:</b>\n{$this->contactMessage}";
            try {
                $response = \Illuminate\Support\Facades\Http::post("https://api.telegram.org/bot{$botToken}/sendMessage", [
                    'chat_id' => $chatId,
                    'text' => $texto,
                    'parse_mode' => 'HTML'
                ]);
                $enviouTelegram = $response->successful();
            } catch (\Exception $e) {
                // ignore
            }
        }
        if ($enviouTelegram) {
            \Flux::toast(variant: 'success', text: 'Mensagem enviada com sucesso!');
        } else {
            \Flux::toast(variant: 'warning', text: 'Mensagem registrada. (Falha temporária ao enviar ao Telegram)');
        }
        $this->reset(['contactMessage']);
    }


    public function with(): array
    {
        $user = auth()->user();

        if ($user->isMembro()) {
            $membro = $user->membro;
            $resumosPendentes = collect();
            $resumosRegularizados = collect();
            if ($membro) {
                $todosResumos = Resumo::where('idt_membro', $membro->idt_membro)
                ->orderByDesc('num_ano')
                ->orderByDesc('num_mes')
                ->get();

                $resumosPendentes = $todosResumos->where('ind_pago', false);
                $resumosRegularizados = $todosResumos->where('ind_pago', true);
            }
            return [
                'isMembroDashboard' => true,
                'membro' => $membro,
                'todosResumos' => $todosResumos ?? collect(),
                'resumosPendentes' => $resumosPendentes,
                'resumosRegularizados' => $resumosRegularizados,
                'associacoes' => \App\Models\Associacao::orderBy('nom_associacao')->get(),
            ];
        }

        $isAdmin = $user->isAdmin();
        $isManager = $isAdmin || $user->isDiretor();
        $isAdminDashboard = $isAdmin && !$user->isDiretor();

        $dadosDashboard = [];
        $mesesDisponiveis = collect();
        $totalInadimplentes = 0;
        $totalAdimplentes = 0;
        $totalRecebido = 0;
        $valorRecuperar = 0;
        $totalMembrosAtivos = 0;
        $totalAssociacoes = \App\Models\Associacao::count();
        $allAssociacoes = \App\Models\Associacao::orderBy('nom_associacao')->get();

        if ($isAdminDashboard) {
            // Lógica do Dashboard Global para Admin
            
            $importacoes = Ofx::withoutGlobalScope('associacao')->latest();
            if ($this->selectedAssociacaoId) {
                $importacoes->where('idt_associacao', $this->selectedAssociacaoId);
            }
            $importacoes = $importacoes->get();
            
            $transacoesQuery = Transacao::query();
            if ($this->selectedAssociacaoId) {
                $transacoesQuery->whereHas('ofx', function($q) {
                    $q->withoutGlobalScope('associacao')->where('idt_associacao', $this->selectedAssociacaoId);
                });
            } else {
                $transacoesQuery->whereHas('ofx', function($q) {
                    $q->withoutGlobalScope('associacao');
                });
            }

            if ($this->selectedImportId) {
                $transacoesQuery->where('idt_ofx', $this->selectedImportId);
            }

            $cloneCreditos = clone $transacoesQuery;
            $cloneDebitos = clone $transacoesQuery;
            $clonePendentes = clone $transacoesQuery;

            $valoresRecebidos = (float) $cloneCreditos->where('tip_transacao', 'CREDIT')->sum('val_transacao');
            $valoresPagos = abs((float) $cloneDebitos->where('tip_transacao', 'DEBIT')->sum('val_transacao'));
            $valoresPendentes = (float) $clonePendentes->where('tip_transacao', 'CREDIT')->whereNull('idt_membro')->sum('val_transacao');

            $membrosQuery = Membro::withoutGlobalScope('associacao')->with('associacao')->where('ind_aprovado', true);
            if ($this->selectedAssociacaoId) {
                $membrosQuery->where('idt_associacao', $this->selectedAssociacaoId);
            }
            $membros = $membrosQuery->get();
            $totalMembrosAtivos = $membros->count();
            
            $valorEsperado = $membros->sum(fn($m) => $m->associacao?->val_taxa ?? 0);

            if ($this->selectedImportId) {
                $pagosIds = Resumo::withoutGlobalScope('associacao')
                    ->where('idt_ofx', $this->selectedImportId)
                    ->where('ind_pago', true)
                    ->pluck('idt_membro')
                    ->filter()
                    ->toArray();
                
                $totalAdimplentes = count(array_unique($pagosIds));
                $totalInadimplentes = $totalMembrosAtivos - $totalAdimplentes;
            } else {
                // If no OFX is selected, check who has AT LEAST ONE unpaid Resumo
                $inadimplentesQuery = Resumo::withoutGlobalScope('associacao')->where('ind_pago', false);
                if ($this->selectedAssociacaoId) {
                    $inadimplentesQuery->whereHas('ofx', function($q) {
                        $q->withoutGlobalScope('associacao')->where('idt_associacao', $this->selectedAssociacaoId);
                    });
                }
                $resumosInadimplentes = $inadimplentesQuery->get();
                $totalInadimplentes = 0;
                
                foreach ($membros as $m) {
                    if ($resumosInadimplentes->contains('idt_membro', $m->idt_membro)) {
                        $totalInadimplentes++;
                    }
                }
            }

            return [
                'isMembroDashboard' => false,
                'isAdminDashboard' => true,
                'isDiretor' => false,
                'importacoes' => $importacoes,
                'importacaoSelecionada' => null,
                'dadosDashboard' => [],
                'mesesDisponiveis' => collect(),
                'totalAdimplentes' => $totalAdimplentes ?? 0,
                'totalInadimplentes' => $totalInadimplentes,
                'totalMembrosAtivos' => $totalMembrosAtivos,
                'valoresRecebidos' => $valoresRecebidos,
                'valoresPagos' => $valoresPagos,
                'valoresPendentes' => $valoresPendentes,
                'valorEsperado' => $valorEsperado,
                'allAssociacoes' => $allAssociacoes,
            ];
        }

        // Lógica do Dashboard Diretor (Por OFX)
        // Lógica do Dashboard Diretor (Por Ano)
        $this->selectedYear = $this->selectedYear ?? (int) date('Y');
        $selectedYear = $this->selectedYear;

        $resumos = Resumo::where('num_ano', $selectedYear)->get();

        $dadosDashboard = [];
        $mesesDisponiveis = collect();
        $totaisPorMes = [];

        $nomesMeses = [
            1 => 'Janeiro', 2 => 'Fevereiro', 3 => 'Março', 4 => 'Abril',
            5 => 'Maio', 6 => 'Junho', 7 => 'Julho', 8 => 'Agosto',
            9 => 'Setembro', 10 => 'Outubro', 11 => 'Novembro', 12 => 'Dezembro'
        ];

        for ($m = 1; $m <= 12; $m++) {
            $mesesDisponiveis->push((object)[
                'num_ano' => $selectedYear,
                'num_mes' => $m,
                'nom_mes' => substr($nomesMeses[$m], 0, 3)
            ]);
            $totaisPorMes[$selectedYear . '-' . $m] = ['total' => 0, 'identificado' => 0];
        }

        // Transações Avulsas / Não Identificadas
        $resumosAvulsos = $resumos->whereNull('idt_membro');
        if ($resumosAvulsos->isNotEmpty()) {
            $linha = [
                'nome' => 'Transações Avulsas / Não Identificadas',
                'membro_id' => null,
                'is_member' => false,
                'meses' => [],
                'total' => 0,
                'situacao' => 'Adimplente',
            ];
            foreach ($mesesDisponiveis as $mesRef) {
                $valor = $resumosAvulsos->where('num_mes', $mesRef->num_mes)->sum('val_total');
                $linha['meses'][] = [
                    'key' => $mesRef->num_ano . '-' . $mesRef->num_mes,
                    'value' => $valor,
                    'has_payment' => $valor > 0,
                ];
                $linha['total'] += $valor;
                $totaisPorMes[$mesRef->num_ano . '-' . $mesRef->num_mes]['total'] += $valor;
            }
            $dadosDashboard[] = $linha;
        }

        $membrosAtivosDiretor = Membro::with('associacao')->where('ind_aprovado', true)->get();
        $currentMonth = (int) date('n');
        $currentYearAtual = (int) date('Y');

        foreach ($membrosAtivosDiretor as $membro) {
            $membroId = $membro->idt_membro;
            $resumosMembro = $resumos->where('idt_membro', $membroId);
            
            $linha = [
                'nome' => $membro->nom_membro,
                'membro_id' => $membroId,
                'is_member' => true,
                'meses' => [],
                'total' => 0,
                'situacao' => 'Adimplente',
            ];
            
            $joinedYear = (int) $membro->created_at->format('Y');
            $joinedMonth = (int) $membro->created_at->format('n');
            
            $valTaxa = (float) ($membro->associacao?->val_taxa ?? 0);
            $valAnual = (float) ($membro->associacao?->val_anual ?? 0);
            
            $hasInadimplencia = false;

            foreach ($mesesDisponiveis as $mesRef) {
                $m = $mesRef->num_mes;
                
                $isExpected = false;
                if ($selectedYear < $currentYearAtual) {
                    if ($joinedYear < $selectedYear || ($joinedYear === $selectedYear && $joinedMonth <= $m)) {
                        $isExpected = true;
                    }
                } elseif ($selectedYear === $currentYearAtual) {
                    if ($m <= $currentMonth && ($joinedYear < $selectedYear || ($joinedYear === $selectedYear && $joinedMonth <= $m))) {
                        $isExpected = true;
                    }
                }

                $valor = (float) $resumosMembro->where('num_mes', $m)->sum('val_total');
                
                if ($isExpected) {
                    if ($valTaxa > 0) {
                        if ($valor < $valTaxa) {
                            $hasInadimplencia = true;
                        }
                    } else {
                        $isPaid = $resumosMembro->where('num_mes', $m)->where('ind_pago', true)->isNotEmpty();
                        if (!$isPaid && $valor <= 0) {
                            $hasInadimplencia = true;
                        }
                    }
                }

                $linha['meses'][] = [
                    'key' => $mesRef->num_ano . '-' . $mesRef->num_mes,
                    'value' => $valor,
                    'has_payment' => $valor > 0,
                ];
                $linha['total'] += $valor;
                
                $totaisPorMes[$mesRef->num_ano . '-' . $mesRef->num_mes]['total'] += $valor;
                $totaisPorMes[$mesRef->num_ano . '-' . $mesRef->num_mes]['identificado'] += $valor;
            }
            
            if ($valAnual > 0 && $linha['total'] >= $valAnual) {
                $linha['situacao'] = 'Adimplente';
            } elseif ($hasInadimplencia) {
                $linha['situacao'] = 'Inadimplente';
            } else {
                $linha['situacao'] = 'Adimplente';
            }
            
            $dadosDashboard[] = $linha;
        }

        $membrosIdsAtivos = $membrosAtivosDiretor->pluck('idt_membro')->toArray();
        $resumosInativos = $resumos->whereNotNull('idt_membro')->whereNotIn('idt_membro', $membrosIdsAtivos)->groupBy('idt_membro');
        foreach ($resumosInativos as $membroId => $resumosMembro) {
            $membroInativo = Membro::withoutGlobalScope('associacao')->find($membroId);
            $linha = [
                'nome' => ($membroInativo ? $membroInativo->nom_membro : 'Membro Excluído') . ' (Inativo)',
                'membro_id' => $membroId,
                'is_member' => true,
                'meses' => [],
                'total' => 0,
                'situacao' => 'Inativo',
            ];
            foreach ($mesesDisponiveis as $mesRef) {
                $m = $mesRef->num_mes;
                $valor = $resumosMembro->where('num_mes', $m)->sum('val_total');
                $linha['meses'][] = [
                    'key' => $mesRef->num_ano . '-' . $mesRef->num_mes,
                    'value' => $valor,
                    'has_payment' => $valor > 0,
                ];
                $linha['total'] += $valor;
                $totaisPorMes[$mesRef->num_ano . '-' . $mesRef->num_mes]['total'] += $valor;
                $totaisPorMes[$mesRef->num_ano . '-' . $mesRef->num_mes]['identificado'] += $valor;
            }
            $dadosDashboard[] = $linha;
        }

        $importacoes = collect();
        $importacaoSelecionada = null;
        
        $currentYear = (int) date('Y');
        $currentMonth = (int) date('n');
        
        $isCurrentYear = $selectedYear === $currentYear;
        $monthsToConsider = $isCurrentYear ? $currentMonth : 12;

        // Cálculos Globais da Associação
        $totalRecebidoGeral = Resumo::where('num_ano', $selectedYear)->sum('val_total');
        $totalNaoIdentificado = Resumo::whereNull('idt_membro')->where('num_ano', $selectedYear)->sum('val_total');
        $totalPagoDespesas = abs((float) \App\Models\Transacao::where('tip_transacao', 'DEBIT')
            ->whereYear('dat_transacao', $selectedYear)
            ->sum('val_transacao'));

        $membrosAtivos = Membro::with('associacao')->where('ind_aprovado', true)->get();
        $totalAdimplentesGlobais = 0;
        $totalInadimplentesGlobais = 0;

        $resumosAno = Resumo::where('num_ano', $selectedYear)->where('ind_pago', true)->get();
        $pagosPorMembro = $resumosAno->groupBy('idt_membro');

        foreach ($membrosAtivos as $membro) {
            $joinedYear = (int) $membro->created_at->format('Y');
            $joinedMonth = (int) $membro->created_at->format('n');
            
            $valTaxa = (float) ($membro->associacao?->val_taxa ?? 0);
            $valAnual = (float) ($membro->associacao?->val_anual ?? 0);
            
            $pagos = $pagosPorMembro->get($membro->idt_membro, collect());
            $totalPagoAno = (float) $pagos->sum('val_total');
            
            if ($valAnual > 0 && $totalPagoAno >= $valAnual) {
                $totalAdimplentesGlobais++;
                continue;
            }
            
            $isInadimplente = false;
            for ($m = 1; $m <= $monthsToConsider; $m++) {
                if ($joinedYear < $selectedYear || ($joinedYear === $selectedYear && $joinedMonth <= $m)) {
                    $pagosNoMes = $pagos->where('num_mes', $m);
                    $valorNoMes = (float) $pagosNoMes->sum('val_total');
                    
                    if ($valTaxa > 0) {
                        if ($valorNoMes < $valTaxa) {
                            $isInadimplente = true;
                            break;
                        }
                    } else {
                        if ($pagosNoMes->isEmpty()) {
                            $isInadimplente = true;
                            break;
                        }
                    }
                }
            }
            
            if ($isInadimplente) {
                $totalInadimplentesGlobais++;
            } else {
                $totalAdimplentesGlobais++;
            }
        }

        return [
            'isMembroDashboard' => false,
            'isAdminDashboard' => false,
            'isDiretor' => true,
            'importacoes' => $importacoes,
            'importacaoSelecionada' => $importacaoSelecionada,
            'dadosDashboard' => $dadosDashboard,
            'mesesDisponiveis' => $mesesDisponiveis,
            'totaisPorMes' => $totaisPorMes,
            'totalRecebido' => $totalRecebidoGeral,
            'totalPagoDespesas' => $totalPagoDespesas,
            'totalNaoIdentificado' => $totalNaoIdentificado,
            'totalAdimplentes' => $totalAdimplentesGlobais,
            'totalInadimplentes' => $totalInadimplentesGlobais,
            'totalMembrosAtivos' => $membrosAtivos->count(),
            'totalAssociacoes' => $totalAssociacoes,
            'allAssociacoes' => $allAssociacoes,
        ];
    }
}; ?>

    <div class="flex h-full w-full flex-1 flex-col gap-6 p-6" x-data="{}" x-on:open-wa-link.window="window.open($event.detail.url, '_blank')">

        {{-- Toast alerts --}}
        @persist('toast')
            <flux:toast.group>
                <flux:toast />
            </flux:toast.group>
        @endpersist

        @if($isMembroDashboard)
            <div class="pc-page">
                @if(!$membro)
                    {{-- ── Membro não encontrado ── --}}
                    <div class="pc-page-header">
                        <div>
                            <div class="pc-label" style="margin-bottom:0.4rem">Associação</div>
                            <h1 class="pc-page-title">Minha Associação</h1>
                        </div>
                    </div>

                    <div style="max-width:560px;margin:0 auto">
                        <div class="pc-alert warning" style="margin-bottom:1.5rem">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;margin-top:1px"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                            <div>
                                <strong>Cadastro não localizado</strong><br>
                                <span style="font-size:0.8125rem">O e-mail <strong>{{ auth()->user()->email }}</strong> não está vinculado a nenhum membro. Envie uma solicitação abaixo.</span>
                            </div>
                        </div>

                        <div class="pc-card">
                            <div class="pc-card-header">
                                <span class="pc-card-title">
                                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                                    Solicitar registro de associado
                                </span>
                            </div>
                            <div class="pc-card-body">
                                <form wire:submit="submitContact" style="display:flex;flex-direction:column;gap:1rem">
                                    <flux:input label="Seu nome" wire:model="contactName" />
                                    <flux:input label="Seu e-mail" wire:model="contactEmail" disabled />
                                    <x-select-associacao label="Associação" wire:model="contactAssociacaoId" placeholder="Selecione a associação..." disabled />
                                    <flux:textarea label="Mensagem para a administração" wire:model="contactMessage" rows="4" placeholder="Olá, gostaria de solicitar a vinculação do meu e-mail à minha conta de associado..." />
                                    <button type="submit" class="pc-btn pc-btn-primary" style="width:100%;justify-content:center">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                                        Enviar solicitação
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                @elseif(!$membro->ind_aprovado)
                    {{-- ── Vinculação pendente de aprovação ── --}}
                    <div class="pc-page-header">
                        <div>
                            <div class="pc-label" style="margin-bottom:0.4rem">Associação</div>
                            <h1 class="pc-page-title">Minha Associação</h1>
                        </div>
                    </div>

                    <div style="max-width:560px;margin:0 auto">
                        <div class="pc-alert warning" style="margin-bottom:1.5rem">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;margin-top:1px"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                            <div>
                                <strong>Aprovação Pendente</strong><br>
                                <span style="font-size:0.8125rem">Sua vinculação à associação <strong>{{ $membro->associacao?->nom_associacao }}</strong> está aguardando aprovação de um diretor ou administrador. Por favor, aguarde a liberação do seu cadastro.</span>
                            </div>
                        </div>
                    </div>

                @else
                    {{-- ── Associado encontrado ── --}}
                    <div class="pc-page-header">
                        <div style="display:flex;align-items:center;gap:1rem">
                            <div>
                                <div class="pc-label" style="margin-bottom:0.2rem">Associação</div>
                                <h1 class="pc-page-title" style="font-size:1.4rem">{{ $membro->associacao?->nom_associacao }}</h1>
                                <p class="pc-page-subtitle">Membro desde {{ $membro->created_at->format('M/Y') }}</p>
                            </div>
                        </div>
                        <div style="display:flex;align-items:center;gap:0.5rem">
                            @if($resumosPendentes->count() > 0)
                                <span class="pc-badge red">
                                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>
                                    {{ $resumosPendentes->count() }} pendência(s)
                                </span>
                            @endif
                        </div>
                    </div>

                    {{-- Tabs --}}
                    <div class="pc-tabs">
                        <button class="pc-tab {{ $activeTab === 'pagamentos' ? 'active' : '' }}" wire:click="$set('activeTab','pagamentos')">Pagamentos</button>
                        <button class="pc-tab {{ $activeTab === 'contato' ? 'active' : '' }}" wire:click="$set('activeTab','contato')">Fale com a Associação</button>
                    </div>

                    <div style="display:grid;grid-template-columns:1fr 280px;gap:1.5rem;align-items:start" class="assoc-grid">

                        {{-- ── Conteúdo principal ── --}}
                        <div>

                            @if($activeTab === 'pagamentos')

                                {{-- Contribuições --}}
                                <div class="pc-card">
                                    <div class="pc-card-header" style="flex-direction: column; align-items: flex-start; gap: 0.5rem;">
                                        <div style="display:flex; width: 100%; justify-content: space-between; align-items: center;">
                                            <span class="pc-card-title">
                                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="color:var(--pc-primary)"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                                                Contribuições
                                            </span>
                                            <span style="font-size:0.78rem;color:var(--pc-subtle)">{{ $todosResumos->count() }} registro(s)</span>
                                        </div>
                                        @if($resumosPendentes->count() > 0 && $membro->associacao?->chave_pix)
                                            <div style="font-size:0.78rem;color:var(--pc-subtle); background: var(--pc-red-lt); padding: 0.75rem; border-radius: 6px; width: 100%;">
                                                <strong style="color: var(--pc-red);">Atenção:</strong> Você possui contribuições pendentes. Realize o pagamento via PIX utilizando a chave: 
                                                <strong style="user-select:all; color: var(--pc-text);">{{ $membro->associacao->chave_pix }}</strong>
                                            </div>
                                        @endif
                                    </div>
                                    @if($todosResumos->isEmpty())
                                        <div class="pc-empty" style="padding:2.5rem 1.5rem">
                                            <div class="pc-empty-title">Nenhum histórico encontrado</div>
                                            <div class="pc-empty-desc">As contribuições aparecerão aqui após o processamento.</div>
                                        </div>
                                    @else
                                    <div style="overflow-x:auto">
                                        <table class="pc-table">
                                            <thead>
                                                <tr>
                                                    <th>Competência</th>
                                                    <th>Valor</th>
                                                    <th>Transações</th>
                                                    <th>Situação</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach($todosResumos as $resumo)
                                                <tr wire:key="r{{ $resumo->idt_resumo }}">
                                                    <td class="cell-primary">{{ $resumo->nom_mes }}/{{ $resumo->num_ano }}</td>
                                                    <td class="cell-mono" style="color: {{ $resumo->ind_pago ? 'var(--pc-green)' : 'var(--pc-red)' }}; font-weight:600">R$ {{ number_format($resumo->val_total, 2, ',', '.') }}</td>
                                                    <td style="color:var(--pc-subtle)">{{ $resumo->num_transacao }} depósito(s)</td>
                                                    <td>
                                                        @if($resumo->ind_pago)
                                                            <span class="pc-badge green">Pago</span>
                                                        @else
                                                            <span class="pc-badge red">Pendente</span>
                                                        @endif
                                                    </td>
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                    @endif
                                </div>

                            @endif


                            @if($activeTab === 'contato')
                            <div class="pc-card">
                                <div class="pc-card-header">
                                    <span class="pc-card-title">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                                        Mensagem para a associação
                                    </span>
                                </div>
                                <div class="pc-card-body">
                                    <p style="font-size:0.8125rem;color:var(--pc-muted);margin-bottom:1.25rem;line-height:1.55">
                                        Olá <strong>{{ $membro->nom_apelido ?? $membro->nom_membro }}</strong>, sua mensagem será enviada a sua associação <strong>{{ $membro->associacao?->nom_associacao }}</strong>.
                                    </p>
                                    <form wire:submit="submitContact" style="display:flex;flex-direction:column;gap:1rem">
                                        <flux:textarea label="Mensagem" wire:model="contactMessage" rows="5" placeholder="Escreva sua solicitação aqui..." />
                                        <button type="submit" class="pc-btn pc-btn-primary" style="width:100%;justify-content:center">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                                            Enviar mensagem
                                        </button>
                                    </form>
                                </div>
                            </div>
                            @endif
                        </div>

                        {{-- ── Sidebar ── --}}
                        <div style="display:flex;flex-direction:column;gap:1.25rem">

                            {{-- Status financeiro --}}
                            <div class="pc-card">
                                <div class="pc-card-header">
                                    <span class="pc-card-title">Situação financeira</span>
                                </div>
                                <div class="pc-card-body">
                                    @if($resumosPendentes->count() > 0)
                                        <div style="display:flex;align-items:center;gap:0.875rem">
                                            <div class="pc-stat-icon red" style="width:40px;height:40px;border-radius:9px">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                            </div>
                                            <div>
                                                <div style="font-size:0.7rem;color:var(--pc-subtle);font-weight:600;text-transform:uppercase;letter-spacing:0.08em">Status</div>
                                                <div style="font-size:1rem;font-weight:700;color:var(--pc-red)">Pendente de pagamento</div>
                                                <div style="font-size:0.78rem;color:var(--pc-subtle)">{{ $resumosPendentes->count() }} pendência(s)</div>
                                            </div>
                                        </div>
                                    @else
                                        <div style="display:flex;align-items:center;gap:0.875rem">
                                            <div class="pc-stat-icon green" style="width:40px;height:40px;border-radius:9px">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                                            </div>
                                            <div>
                                                <div style="font-size:0.7rem;color:var(--pc-subtle);font-weight:600;text-transform:uppercase;letter-spacing:0.08em">Status</div>
                                                <div style="font-size:1rem;font-weight:700;color:var(--pc-green)">Regularizado</div>
                                                <div style="font-size:0.78rem;color:var(--pc-subtle)">Sem débitos pendentes</div>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>

                            {{-- Perfil resumido --}}
                            <div class="pc-card">
                                <div class="pc-card-header" style="display: flex; justify-content: space-between; align-items: center;">
                                    <span class="pc-card-title">Perfil</span>
                                    <a href="/settings/profile" style="font-size: 0.75rem; color: var(--pc-primary); text-decoration: none; font-weight: 600;">Editar Perfil</a>
                                </div>
                                <div class="pc-card-body" style="display:flex;flex-direction:column;gap:0.875rem">
                                    <div>
                                        <div style="font-size:0.7rem;color:var(--pc-subtle);font-weight:600;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.2rem">Tipo de associação</div>
                                        <span class="pc-badge muted">{{ $membro->tip_associado->label() }}</span>
                                    </div>
                                    <div>
                                        <div style="font-size:0.7rem;color:var(--pc-subtle);font-weight:600;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.2rem">Nome registrado</div>
                                        <div style="font-size:0.875rem;font-weight:600;color:var(--pc-text)">{{ $membro->nom_membro }}</div>
                                    </div>
                                    <div>
                                        <div style="font-size:0.7rem;color:var(--pc-subtle);font-weight:600;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.2rem">E-mail</div>
                                        <div style="font-size:0.8125rem;color:var(--pc-muted)">{{ $membro->eml_membro }}</div>
                                    </div>
                                    <div>
                                        <div style="font-size:0.7rem;color:var(--pc-subtle);font-weight:600;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:0.2rem">Membro desde</div>
                                        <div style="font-size:0.8125rem;color:var(--pc-muted)">{{ $membro->created_at->format('d/m/Y') }}</div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <style>
                        @media(max-width:768px){
                            .assoc-grid{ grid-template-columns:1fr !important; }
                        }
                    </style>
                @endif
            </div>
        @else
            <!-- Filtros -->
            @if($isAdminDashboard)
                <div class="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-neutral-200 bg-white p-4 shadow-sm dark:border-neutral-700 dark:bg-zinc-900 mb-6">
                    <div class="flex items-center gap-3 w-full sm:w-auto">
                        <div class="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-blue-100 text-blue-600 dark:bg-blue-900/30">
                            <flux:icon name="building-office-2" class="size-5" />
                        </div>
                        <div class="flex flex-col gap-1 flex-1 sm:flex-initial">
                            <p class="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Associação Selecionada</p>
                            <x-select-associacao wire:model.live="selectedAssociacaoId" class="w-full sm:w-64" :show-all-option="true" />
                        </div>
                        
                        <div class="flex items-center gap-3 w-full sm:w-auto mt-4 sm:mt-0 sm:ml-4 border-t sm:border-t-0 sm:border-l border-neutral-200 dark:border-neutral-700 pt-4 sm:pt-0 sm:pl-4">
                            <div class="flex flex-col gap-1 w-full sm:w-64">
                                <p class="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Arquivo OFX (Período)</p>
                                <flux:select wire:model.live="selectedImportId" class="w-full">
                                    <flux:select.option value="">Todos os Períodos</flux:select.option>
                                    @foreach($importacoes as $ofx)
                                        <flux:select.option value="{{ $ofx->idt_ofx }}">
                                            {{ $ofx->des_arquivo }}
                                        </flux:select.option>
                                    @endforeach
                                </flux:select>
                            </div>
                        </div>
                    </div>
                </div>
            @else
                <!-- Filtro de Ano (Diretor) -->
                <div class="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-neutral-200 bg-white p-4 shadow-sm dark:border-neutral-700 dark:bg-zinc-900 mb-6">
                    <div class="flex items-center gap-3 w-full sm:w-auto">
                        <div class="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-blue-100 text-blue-600 dark:bg-blue-900/30">
                            <flux:icon name="calendar" class="size-5" />
                        </div>
                        <div>
                            <p class="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Ano do Acompanhamento</p>
                            <p class="text-sm font-bold text-neutral-800 dark:text-neutral-100">{{ $selectedYear }}</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2 w-full sm:w-auto">
                        <flux:select wire:model.live="selectedYear" class="w-full sm:w-32">
                            @for($y = date('Y'); $y >= 2024; $y--)
                                <flux:select.option value="{{ $y }}">{{ $y }}</flux:select.option>
                            @endfor
                        </flux:select>
                    </div>
                </div>
            @endif


            <!-- Cards de Estatísticas -->
            @if($isAdminDashboard)
            <div class="grid auto-rows-min gap-4 md:grid-cols-3 lg:grid-cols-6 mb-6">
                <flux:card class="flex flex-col items-start justify-between p-4 space-y-2">
                    <p class="text-[10px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Valores Recebidos</p>
                    <div class="flex w-full items-center justify-between">
                        <p class="text-lg font-bold text-green-600">R$ {{ number_format($valoresRecebidos, 2, ',', '.') }}</p>
                        <flux:icon name="arrow-trending-up" class="size-5 text-green-500 opacity-60" />
                    </div>
                </flux:card>
                <flux:card class="flex flex-col items-start justify-between p-4 space-y-2">
                    <p class="text-[10px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Valores Pagos</p>
                    <div class="flex w-full items-center justify-between">
                        <p class="text-lg font-bold text-red-600">R$ {{ number_format($valoresPagos, 2, ',', '.') }}</p>
                        <flux:icon name="arrow-trending-down" class="size-5 text-red-500 opacity-60" />
                    </div>
                </flux:card>
                <flux:card class="flex flex-col items-start justify-between p-4 space-y-2">
                    <p class="text-[10px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Valores Pendentes</p>
                    <div class="flex w-full items-center justify-between">
                        <p class="text-lg font-bold text-orange-500">R$ {{ number_format($valoresPendentes, 2, ',', '.') }}</p>
                        <flux:icon name="exclamation-circle" class="size-5 text-orange-400 opacity-60" />
                    </div>
                </flux:card>
                <flux:card class="flex flex-col items-start justify-between p-4 space-y-2">
                    <p class="text-[10px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Valor Esperado</p>
                    <div class="flex w-full items-center justify-between">
                        <p class="text-lg font-bold text-blue-600">R$ {{ number_format($valorEsperado, 2, ',', '.') }}</p>
                        <flux:icon name="banknotes" class="size-5 text-blue-500 opacity-60" />
                    </div>
                </flux:card>
                <flux:card class="flex flex-col items-start justify-between p-4 space-y-2">
                    <p class="text-[10px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Membros Ativos</p>
                    <div class="flex w-full items-center justify-between">
                        <p class="text-xl font-bold text-blue-600">{{ $totalMembrosAtivos }}</p>
                        <flux:icon name="users" class="size-5 text-blue-500 opacity-60" />
                    </div>
                </flux:card>
                <flux:card class="flex flex-col items-start justify-between p-4 space-y-2">
                    <p class="text-[10px] font-bold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Membros Inadimplentes</p>
                    <div class="flex w-full items-center justify-between">
                        <p class="text-xl font-bold text-red-600">{{ $totalInadimplentes }}</p>
                        <flux:icon name="x-circle" class="size-5 text-red-500 opacity-60" />
                    </div>
                </flux:card>
            </div>
            @else
            <div class="grid auto-rows-min gap-4 md:grid-cols-3 lg:grid-cols-6 mb-6">
                <flux:card class="flex items-center justify-between p-5">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Total Recebido</p>
                        <p class="mt-1 text-2xl font-bold text-neutral-800 dark:text-neutral-100">R$ {{ number_format($totalRecebido,2,',','.') }}</p>
                    </div>
                    <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-green-100 text-green-600 dark:bg-green-900/30">
                        <flux:icon name="banknotes" class="size-5" />
                    </div>
                </flux:card>
                <flux:card class="flex items-center justify-between p-5">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Total Pago</p>
                        <p class="mt-1 text-2xl font-bold text-red-600">R$ {{ number_format($totalPagoDespesas,2,',','.') }}</p>
                    </div>
                    <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-red-100 text-red-600 dark:bg-red-900/30">
                        <flux:icon name="arrow-trending-down" class="size-5" />
                    </div>
                </flux:card>
                <flux:card class="flex items-center justify-between p-5">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Não Identificado</p>
                        <p class="mt-1 text-2xl font-bold text-orange-600">R$ {{ number_format($totalNaoIdentificado,2,',','.') }}</p>
                    </div>
                    <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-orange-100 text-orange-600 dark:bg-orange-900/30">
                        <flux:icon name="question-mark-circle" class="size-5" />
                    </div>
                </flux:card>
                <flux:card class="flex items-center justify-between p-5">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Adimplentes</p>
                        <p class="mt-1 text-2xl font-bold text-green-600">{{ $totalAdimplentes }}</p>
                    </div>
                    <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-green-100 text-green-600 dark:bg-green-900/30">
                        <flux:icon name="check-circle" class="size-5" />
                    </div>
                </flux:card>
                <flux:card class="flex items-center justify-between p-5">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Inadimplentes</p>
                        <p class="mt-1 text-2xl font-bold text-red-600">{{ $totalInadimplentes }}</p>
                    </div>
                    <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-red-100 text-red-600 dark:bg-red-900/30">
                        <flux:icon name="exclamation-triangle" class="size-5" />
                    </div>
                </flux:card>
                <flux:card class="flex items-center justify-between p-5">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wider text-neutral-500 dark:text-neutral-400">Membros Ativos</p>
                        <p class="mt-1 text-2xl font-bold text-blue-600">{{ $totalMembrosAtivos }}</p>
                    </div>
                    <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-100 text-blue-600 dark:bg-blue-900/30">
                        <flux:icon name="users" class="size-5" />
                    </div>
                </flux:card>
            </div>
            @endif

                <!-- Seções Principais -->
                <div class="space-y-6">
                    @if($isDiretor)
                    {{-- Tabela de Acompanhamento Mensal --}}
                    <flux:card class="p-0 overflow-hidden mt-6">
                        <div class="flex items-center justify-between border-b border-neutral-100 px-5 py-4 dark:border-neutral-800 bg-neutral-50/50 dark:bg-zinc-800/20">
                            <h3 class="text-sm font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 flex items-center gap-2">
                                <flux:icon name="table-cells" class="size-4 text-blue-600" /> Acompanhamento Mensal por Pagador
                            </h3>
                            <span class="text-xs text-neutral-500">{{ count($dadosDashboard) }} pagadores</span>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full text-sm">
                                <thead>
                                    <tr class="bg-neutral-50 text-xs uppercase tracking-wider text-neutral-600 dark:bg-zinc-800/50 dark:text-neutral-400">
                                        <th class="px-4 py-3 text-left font-bold">Pagador (MEMO)</th>
                                        <th class="px-4 py-3 text-right font-bold">Total</th>
                                        @foreach($mesesDisponiveis as $month)
                                            <th class="px-3 py-3 text-center font-bold">{{ $month->nom_mes }}<span class="block text-[10px] font-normal opacity-60">{{ $month->num_ano }}</span></th>
                                        @endforeach
                                        <th class="px-4 py-3 text-center font-bold">Situação</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-neutral-100 dark:divide-neutral-800">
                                    @forelse($dadosDashboard as $row)
                                        <tr class="transition hover:bg-neutral-50/50 dark:hover:bg-zinc-800/30 {{ $row['situacao']==='Inadimplente' ? 'bg-red-50/10 dark:bg-red-950/5' : '' }}">
                                            <td class="px-4 py-3">
                                                <div class="flex items-center gap-2">
                                                    <div class="hidden sm:flex h-8 w-8 items-center justify-center rounded-full bg-neutral-200 text-xs font-bold text-neutral-600 dark:bg-zinc-700 dark:text-neutral-300">
                                                        {{ strtoupper(substr($row['nome'],0,1)) }}
                                                    </div>
                                                    <div>
                                                        <p class="font-semibold text-neutral-800 dark:text-neutral-200">{{ $row['nome'] }}</p>
                                                        @if($row['is_member'])
                                                            <span class="inline-block rounded bg-blue-100 px-1.5 py-0.5 text-[10px] font-bold text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">Membro</span>
                                                        @else
                                                            <span class="inline-block rounded bg-neutral-100 px-1.5 py-0.5 text-[10px] text-neutral-500 dark:bg-zinc-800 dark:text-neutral-400">Não cadastrado</span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="px-4 py-3 text-right font-bold text-neutral-700 dark:text-neutral-300">
                                                R$ {{ number_format($row['total'],0,',','.') }}
                                            </td>
                                            @foreach($row['meses'] as $m)
                                                <td class="px-3 py-3 text-center">
                                                    @if($m['has_payment'])
                                                        <span class="inline-block rounded bg-green-50 px-2 py-1 text-xs font-semibold text-green-700 dark:bg-green-900/20 dark:text-green-400">R$ {{ number_format($m['value'],0,',','.') }}</span>
                                                    @else
                                                        <span class="text-xs font-bold text-neutral-300 dark:text-neutral-600">R$ 0</span>
                                                    @endif
                                                </td>
                                            @endforeach
                                            <td class="px-4 py-3 text-center">
                                                @if($row['situacao'] === 'Adimplente')
                                                    <span class="inline-flex items-center gap-1 rounded bg-green-100 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                                        <flux:icon name="check-circle" class="size-3" /> Adimplente
                                                    </span>
                                                @else
                                                    <span class="inline-flex items-center gap-1 rounded bg-red-100 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-red-700 dark:bg-red-900/30 dark:text-red-400">
                                                        <flux:icon name="exclamation-triangle" class="size-3" /> Inadimplente
                                                    </span>
                                                @endif
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="100%" class="px-4 py-8 text-center text-neutral-500">
                                                Nenhuma pessoa identificada neste ano.
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                                @if(count($dadosDashboard) > 0)
                                <tfoot class="bg-neutral-50 border-t-2 border-neutral-200 dark:bg-zinc-800/50 dark:border-neutral-700">
                                    <tr>
                                        <td class="px-4 py-4 text-left">
                                            <div class="text-xs font-bold uppercase tracking-wider text-neutral-600 dark:text-neutral-400">Total Pago Pelos Membros</div>
                                            <div class="text-[10px] mt-1 text-neutral-500 uppercase tracking-wider">Total Recebido (Geral)</div>
                                        </td>
                                        <td class="px-4 py-4 text-right">
                                            @php
                                                $totalMembrosAno = array_sum(array_column($totaisPorMes, 'identificado'));
                                                $totalGeralAno = array_sum(array_column($totaisPorMes, 'total'));
                                            @endphp
                                            <div class="text-sm font-bold text-green-700 dark:text-green-400">R$ {{ number_format($totalMembrosAno, 0, ',', '.') }}</div>
                                            <div class="text-xs mt-1 font-semibold text-neutral-600 dark:text-neutral-400">R$ {{ number_format($totalGeralAno, 0, ',', '.') }}</div>
                                        </td>
                                        @foreach($mesesDisponiveis as $month)
                                            @php
                                                $key = $month->num_ano . '-' . $month->num_mes;
                                                $tot = $totaisPorMes[$key] ?? ['identificado' => 0, 'total' => 0];
                                            @endphp
                                            <td class="px-3 py-4 text-center">
                                                <div class="text-sm font-bold text-green-700 dark:text-green-400">R$ {{ number_format($tot['identificado'], 0, ',', '.') }}</div>
                                                <div class="text-xs mt-1 font-semibold text-neutral-600 dark:text-neutral-400">R$ {{ number_format($tot['total'], 0, ',', '.') }}</div>
                                            </td>
                                        @endforeach
                                        <td></td>
                                    </tr>
                                </tfoot>
                                @endif
                            </table>
                        </div>
                    </flux:card>                
                    @endif
                </div>
        @endif
    </div>
